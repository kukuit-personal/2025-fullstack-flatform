export class RegisterDto {
  email: string;
  password: string;
  role?: string; // optional, default is 'client'
}