export default function ClientDashboard() {
  return <div>Xin chào Client!</div>
}
