export default function AdminDashboard() {
  return <div>Chào mừng Admin!</div>
}
